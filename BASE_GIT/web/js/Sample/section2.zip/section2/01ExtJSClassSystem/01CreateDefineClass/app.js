Ext.onReady(function() {

Ext.define('MyClass', { // Step 1
	extend : 'Ext.panel.Panel', // Step 2
	title : '안녕하세요 환영합니다.^^',
	initComponent : function() { // Step 3
		var me = this;

		this.callParent(arguments); // Step 4
	}
});

var myClass = Ext.create('MyClass', { // Step 5
	renderTo : Ext.getBody()
});

});